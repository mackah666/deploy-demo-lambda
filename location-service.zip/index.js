exports.handler = async (event) => {
  const response = {
    statusCode: 200,
    body: JSON.stringify("Hello Mackah666 from Lambda!")
  };
  return response;
};
